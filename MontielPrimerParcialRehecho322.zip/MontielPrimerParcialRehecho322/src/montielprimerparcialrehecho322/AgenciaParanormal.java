
package montielprimerparcialrehecho322;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa una agencia encargada de administrar casos paranormales.
 * Permite registrar casos, consultarlos y filtrarlos segun su nivel de riesgo.
 * @author joaqu
 */
public class AgenciaParanormal {
    
    private String nombre;
    private List<CasoParanormal> casos;

    /**
     * Crea un nueva agencia paranormal.
     * @param nombre: nombre de la agencia.
     * @throws IllegalArgumentException si el nombre es inválido.
     */
    public AgenciaParanormal(String nombre) {
        validarString(nombre, "nombre");
        this.nombre = nombre;
        this.casos = new ArrayList<>();
    }
    
     /**
     * Valida que una cadena de texto  o sea nula ni vacía.
     * @param valor: texto a validar.
     * @param campo: nombre del campo validado.
     * 
     * @throws IllegalArgumentException si el texto es inválido.
     */
    protected void validarString(String valor, String campo){
        if (valor == null || valor.isBlank()){
            throw new IllegalArgumentException("El " + campo + " no puede estar vacío.");
        }
    }

    /**
     * Obtiene el nombre de la agencia.
     * @return nombre de la agencia.
     */
    public String getNombre() {
        return this.nombre;
    }

    public List<CasoParanormal> getCasos() {
        return new ArrayList<>(casos);
    }
    
    /**
     * Devuleve la representación textual de la agencia.
     * @return informacion de la agencia.
     */
    @Override
    public String toString() {
        return "AgenciaParanormal{" + "nombre=" + this.nombre + ", casos=" + this.casos + '}';
    }
    
    /**
     * Agrega un caso paranormal a la agencia.
     * @param caso: caso a registrar.
     * 
     * @throws IllegalArgumentException si el caso es nulo.
     * @throws CasoDuplicadoException si el caso ya existe.
     */
    public void agregarCaso(CasoParanormal caso) throws CasoDuplicadoException {
        if (caso == null){
            throw new IllegalArgumentException("No se puede agregar un caso nulo.");
        }
        
        if (casos.contains(caso)){
            throw new CasoDuplicadoException("Ya existe un caso con ese nombre e investigador responsable.");
        }
        casos.add(caso); 
    }
    
    /**
     * Obtiene una copia de los casos registrados.
     * @return lista con los casos registrados.
     */
    public List<CasoParanormal> obtenerCasos(){
        return new ArrayList<>(casos);
    }
    
    /**
     * Obtiene todos los casos que poseen el nivel de riesgo indicado.
     * @param nivelRiesgo: nivel de riesgo a buscar.
     * @return lista de casos que cumplen el criterio.
     * 
     * @throws IllegalArgumentException si el nivel es nulo.
     */
    public List<CasoParanormal> filtrarPorRiesgo(NivelRiesgo nivelRiesgo){
        if (nivelRiesgo == null){
            throw new IllegalArgumentException("El nivel de riesgo no puede ser nulo.");
        }
        
        List<CasoParanormal> filtrados = new ArrayList<>();
        for(CasoParanormal caso : casos){
            if(caso.getNivelRiesgo() == nivelRiesgo){
                filtrados.add(caso);
            }
        }
        
        return filtrados;
    }
}
