
package montielprimerparcialrehecho322;

/**
 * Excepción chequeada que se lanza cuando se intenta agregar a la agencia un casi paranormal ya existente.
 * Un caso se considera duplicado si posee el mismo nombre y el mismo investigador responsable que otro caso registrado.
 * @author joaqu
 */
public class CasoDuplicadoException extends Exception{
    /**
     * Crea una nueva excepción con el mensaje indicado.
     * @param mensaje: descripción del error producido.
     */
    public CasoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
