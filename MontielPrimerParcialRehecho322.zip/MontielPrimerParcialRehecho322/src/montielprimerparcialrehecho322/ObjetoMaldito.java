
package montielprimerparcialrehecho322;
/**
 * Representa un objeto maldito investigado por la agencia.
 * Cada objeto maldito posee un material principal asociado.
 * @author joaqu
 */
public class ObjetoMaldito extends CasoParanormal implements Informable{
    
    private String materialPrincipal;
    
    /**
     * Crea un nuevo objeto maldito.
     * @param nombre: nombre del caso.
     * @param investigadorResponsable: investigador encargado.
     * @param nivelRiesgo: nivel de riesgo del caso.
     * @param materialPrincipal: material principal del objeto.
     * 
     * @throws IllegalArgumentException si algún dato es inválido.
     */
    public ObjetoMaldito(String nombre, String investigadorResponsable, NivelRiesgo nivelRiesgo, String materialPrincipal) {
        super(nombre, investigadorResponsable, nivelRiesgo);
        validarString(materialPrincipal, "materialPrincipal");
        this.materialPrincipal = materialPrincipal;
    }

    /**
     * Obtiene el material principal del objeto maldito.
     * @return material principal.
     */
    public String getMaterialPrincipal() {
        return materialPrincipal;
    }
    
    /**
     * Devuelve una representación textual de un objeto maldito.
     * @return información de un objeto maldito.
     */
    @Override
    public String toString() {
        return "Objeto maldito{" +
            super.toString() +
            ", materialPrincipal=" + materialPrincipal + '}';
    }
    
    /**
     * Genera un informa descriptivo del objeto maldito.
     * @return informe generado.
     */
    @Override
    public String generarInforme(){
        return "Informe del Objeto Maldito: \n"
            + "Nombre: " + getNombre() + "\n"
            + "Investigador: " + getInvestigadorResponsable() + "\n"
            + "Nivel de Riesgo: " + getNivelRiesgo() + "\n"
            + "Material principal: " + getMaterialPrincipal();      
    }
} 
