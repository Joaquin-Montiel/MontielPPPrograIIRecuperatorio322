
package montielprimerparcialrehecho322;
/**
 * Representa los niveles de riesgo posibles para un caso paranormal.
 * @author joaqu
 */
public enum NivelRiesgo {
    BAJO,
    MODERADO,
    CRITICO
}
