
package montielprimerparcialrehecho322;

import java.util.Objects;

/**
 * Representa un caso paranormalinvestigado por una agencia.
 * Cada caso posee un nombre, un investigador responsable y un nivel de riego asociado.
 * @author joaqu
 */
public abstract class CasoParanormal {
   private String nombre;
   private String investigadorResponsable;
   private NivelRiesgo nivelRiesgo;
   
   
   /**
    * Crea un nuevo caso paranormal.
    * @param nombre: nombre del caso.
    * @param investigadorResponsable: investigador encargado del caso.
    * @param nivelRiesgo: nivel de riego del caso.
    * 
    * validos lo datos del nuevo caso, si alguno es inválido se lanza una excepción.
    */
    public CasoParanormal(String nombre, String investigadorResponsable, NivelRiesgo nivelRiesgo) {
        validarString(nombre,"nombre");
        validarString(investigadorResponsable, "investigadorResponsable");
        validarEnum(nivelRiesgo);
        
        this.nombre = nombre;
        this.investigadorResponsable = investigadorResponsable;
        this.nivelRiesgo = nivelRiesgo;
    }
    
    /**
     * Valida que el nivel de riesgo no sea nulo.
     * @param nivelRiesgo: nivel de riesgo a validar.
     * 
     * @throws IllegalArgumentException si el nivel de riesgo es nulo.
     */
    protected void validarEnum(NivelRiesgo nivelRiesgo){
        if (nivelRiesgo == null){
            throw new IllegalArgumentException("El nivel de riesgo no puede ser nulo.");
        }
    }
    
    /**
     * Valida que una cadena de texto  o sea nula ni vacía.
     * @param valor: texto a validar.
     * @param campo: nombre del campo validado.
     * 
     * @throws IllegalArgumentException si el texto es inválido.
     */
    protected void validarString(String valor, String campo){
        if (valor == null || valor.isBlank()){
            throw new IllegalArgumentException("El " + campo + " no puede estar vacío.");
        }
    }
    
    /**
     * Valida que un valor numérico sea positivo.
     * @param valor: valor a validar.
     * @param campo: nombre del campo validado.
     * 
     * @throws IllegalArgumentException si el valor es monor o igual a 0.
     */
    protected void validarPositivo(double valor, String campo){
        if(valor <= 0){
            throw new IllegalArgumentException("El " + campo + " debe ser mayor a cero.");
        }
    }
    
    /**
     * Obtiene el nombre del caso.
     * @return nombre del caso paranormal.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene el investigador responsable.
     * @return investigador responsable del caso.
     */
    public String getInvestigadorResponsable() {
        return this.investigadorResponsable;
    }

    /**
     * Obtiene el nivel de riesgo del caso.
     * @return nivel de riesgo asociado.
     */
    public NivelRiesgo getNivelRiesgo() {
        return this.nivelRiesgo;
    }

    /**
     * Devuelve una representación textual del caso paranormal.
     * @return cadena con los datos principales del caso.
     */
    @Override
    public String toString() {
        return "nombre=" + nombre +
            ", investigadorResponsable=" + investigadorResponsable +
            ", nivelRiesgo=" + nivelRiesgo;
    }
   
    /**
     * Compara dos casos paranormales. Dos casos son iguales 
     * si poseen el mismo nombre e investigado responsable.
     * 
     * @param obj objeto a comparar.
     * @return true silos dos casos son iguales, false en caso contrario.
     */
   @Override 
   public boolean equals(Object obj){
       if (this == obj){
           return true;
       }
       
       if (obj == null || getClass() != obj.getClass()){
           return false;
       }
       
       CasoParanormal cp = (CasoParanormal) obj;
       return nombre.equals(cp.getNombre()) && investigadorResponsable.equals(cp.getInvestigadorResponsable()); 
   }
   
   
   /**
    * Genera el código hash del casp paranormal.
    * @return código hash basado en el nombre y el investigado.
    */
   @Override
   public int hashCode() {
       return Objects.hash(nombre, investigadorResponsable);
   }
}
