
package montielprimerparcialrehecho322;

import java.util.List;

/**
 * Clase principal del sistema.
 * Permite probar el funcionamiento de la agencia paranormal y sus distintos tipos de casos.
 * @author joaqu
 */
public class MontielPrimerParcialRehecho322 {

    public static void main(String[] args) {
        AgenciaParanormal agencia = new AgenciaParanormal("Division Noche Eterna");
        try {
            agencia.agregarCaso(new Aparicion("La Dama del Pasillo", "Irene Vega",NivelRiesgo.CRITICO, "03:33"));
            agencia.agregarCaso(new ObjetoMaldito("Espejo de la Habitacion 12", "Bruno Rios", NivelRiesgo.MODERADO, "Vidrio antiguo"));
            agencia.agregarCaso(new ZonaAnomala("Bosque de las Voces", "Mara Silva",NivelRiesgo.BAJO, 300));
            agencia.agregarCaso(new ZonaAnomala("Tunel sin Retorno", "Irene Vega",NivelRiesgo.CRITICO, 120));
            agencia.agregarCaso(new Aparicion("La Dama del Pasillo", "Irene Vega",NivelRiesgo.MODERADO, "02:15"));
        } catch(CasoDuplicadoException e) {
            System.out.println("No se pudo agregar el caso: " + e.getMessage());
        }
            
        System.out.println("Casos registrados:");
        mostrarCasos(agencia.obtenerCasos());
        System.out.println();
        System.out.println("Casos investigables:");
        investigarCasos(agencia.obtenerCasos());
        System.out.println();
        System.out.println("Informes generados:");
        generarInformes(agencia.obtenerCasos());
        System.out.println();
        System.out.println("Casos de riesgo CRITICO:");
        mostrarCasos(agencia.filtrarPorRiesgo(NivelRiesgo.CRITICO));
    }
    
    /**
     * Muestra por consola todos los casos recibidos.
     * @param casos: lista de casos a mostrar.
     */
    private static void mostrarCasos(List<CasoParanormal> casos) {
        for(CasoParanormal caso : casos){
             System.out.println(caso);
        }
    }
    
    /**
     * Ejecuta la investigacion de todos los casos que implementan la interfaz Investigable.
     * @param casos: lista de casos a procesar.
     */
    private static void investigarCasos(List<CasoParanormal> casos) {
 
        for(CasoParanormal caso : casos){

            if(caso instanceof Investigable){
                System.out.println(((Investigable) caso).investigar());
            }else{
                System.out.println("El caso '" +caso.getNombre() +"' no puede investigarse.");
            }
        }
    }
 
    /**
     * Genera los informes de todos los casos que implementan la interfaz Informable.
     * @param casos: lista de casos a procesar. 
     */
    private static void generarInformes(List<CasoParanormal> casos) {
        for(CasoParanormal caso : casos){

            if(caso instanceof Informable){
                System.out.println(((Informable) caso).generarInforme());
            }else{
                System.out.println("El caso '" + caso.getNombre() + "' no genera informe.");
            }
        }
    } 
     
}
