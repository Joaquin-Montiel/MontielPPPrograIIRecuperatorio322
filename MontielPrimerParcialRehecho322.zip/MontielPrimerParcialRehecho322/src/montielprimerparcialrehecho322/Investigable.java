
package montielprimerparcialrehecho322;
/**
 * Define el comportamiento de los casos que pueden ser investigados por la agencia paranormal.
 * @author joaqu
 */
public interface Investigable {
    /**
     * Realiza la investigación del caso.
     * @return descripción de la investigación realizada.
     */
    String investigar();
}
