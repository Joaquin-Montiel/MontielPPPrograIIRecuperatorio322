
package montielprimerparcialrehecho322;
/**
 * Representa una zona anómala investigada por la agencia.
 * LAs zonas anómalas poseen un radio afectado y pueden investigarse y generar informes.
 * @author joaqu
 */
public class ZonaAnomala extends CasoParanormal implements Investigable, Informable{
    
    private double radioAfectado;
    
    /**
     * Crea una nueva zona anómala.
     * @param nombre: nombre del caso.
     * @param investigadorResponsable: investigador encargado.
     * @param nivelRiesgo:nivel de riesgo.
     * @param radioAfectado: radio afectado expresado en metros.
     * 
     * @throws IllegalArgumentException si algún dato es inválido.
     */
    public ZonaAnomala(String nombre, String investigadorResponsable, NivelRiesgo nivelRiesgo, double radioAfectado) {
        super(nombre, investigadorResponsable, nivelRiesgo);
        validarPositivo(radioAfectado, "radioAfectado");
        this.radioAfectado = radioAfectado;
    }
    
    /**
     * Obtiene el radio afectado de la zona.
     * @return radio afectado en metros.
     */
    public double getRadioAfectado() {
        return radioAfectado;
    }

    /**
     * Devuelve una representción  textual de la zona anómala.
     * @return informacion de la zona.
     */
    @Override
    public String toString(){
        return "ZonaAnomala{" +
                super.toString() + 
                "radioAfectado=" +  radioAfectado + '}';
    }

    /**
     * Realiza una investigacion de la zona anómala.
     * @return descripción de la investigación realizada.
     */
    @Override
    public String investigar() {
        return "Investigando la zona anómala " + getNombre() + "\n" +
                "Estas tienen un nivel de riesgo " + super.getNivelRiesgo() + "\n" + 
                "Y estas ocurren en un radio de " + getRadioAfectado();
    }
    
    /**
     * Genera un inferme descriptivo de la zona anómala.
     * @return informe generado.
     */
    @Override
    public String generarInforme(){
        return "Informe de la Zona Anomala: \n"
            + "Nombre: " + getNombre() + "\n"
            + "Investigador: " + getInvestigadorResponsable() + "\n"
            + "Nivel de Riesgo: " + getNivelRiesgo() + "\n"
            + "Radio afectado: " + getRadioAfectado();  
    }   
}
