
package montielprimerparcialrehecho322;

/**
 * Representa una aparici+on paranormal investigada por una agencia.
 * Las apariciones poseen un horario frecuente y pueden ser investigadas.
 * @author joaqu
 */
public class Aparicion extends CasoParanormal implements Investigable{
    
    private String horarioFrecuente;  
    
    /**
     * Crea una nueva aparición.
     * @param nombre: nombre del caso.
     * @param investigadorResponsable: investigador encargado.
     * @param nivelRiesgo: nivel de riego.
     * @param horarioFrecuente: horario en el que suelen manifestarse.
     * 
     * @throws IllegalArgumentException si algún dato es inválido.
     */
    public Aparicion(String nombre, String investigadorResponsable, NivelRiesgo nivelRiesgo, String horarioFrecuente) {
        super(nombre, investigadorResponsable, nivelRiesgo);
        validarString(horarioFrecuente, "horarioFrecuente");
        this.horarioFrecuente = horarioFrecuente;
    }

    /**
     * Obtiene el horario frecuente de manifestación.
     * @return horario frecuente.
     */
    public String getHorarioFrecuente() {
        return this.horarioFrecuente;
    }

    /**
     * Devuelve una representación textual de la aparición.
     * @return información de la aparición.
     */
    @Override
    public String toString() {
        return "Aparicion{" +
            super.toString() +
            ", horarioFrecuente=" + horarioFrecuente + '}';
    }

    /**
     * Realiza la investigación de la aparición.
     * @return descripción de la investigación realizada.
     */
    @Override
    public String investigar() {
        return "Investigando la aparición " + getNombre() + "\n" +
                "Tiene un nivel de riesgo " + super.getNivelRiesgo() + "\n" + 
                "Y ocurre frecuentemente a las " + getHorarioFrecuente();
    }
}
