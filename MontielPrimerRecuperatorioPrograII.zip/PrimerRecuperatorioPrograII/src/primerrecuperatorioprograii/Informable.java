
package primerrecuperatorioprograii;
/**
 * Define el comportamiento de los casos capaces de generar un informe descriptivo.
 * @author joaqu
 */
public interface Informable {
    
    /**
     * Genera un informe con la información relevante del caso.
     * @return informe fenerado en formato texto.
     */
    String generarInforme();
}
