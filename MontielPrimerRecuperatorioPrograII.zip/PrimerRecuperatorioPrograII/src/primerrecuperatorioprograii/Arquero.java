
package primerrecuperatorioprograii;

public class Arquero extends Futbolista implements Informable{
    
    private int atajadasRealizadas;

    public Arquero(String nombre, String pais, NivelDeExperiencia nivelExperiencia, int nroCamiseta, int partidosDisputados, int atajadasRealizadas) {
        super(nombre, pais, nivelExperiencia, nroCamiseta, partidosDisputados);
        validarNoNegativo(atajadasRealizadas, "atajadasRealizadas");
        this.atajadasRealizadas = atajadasRealizadas;
    }

    public int getAtajadasRealizadas() {
        return this.atajadasRealizadas;
    }

    @Override
    public String toString() {
        return super.toString() + " Arquero{" + "atajadasRealizadas=" + atajadasRealizadas + '}';
    }
    
    @Override
    public String generarInforme() {
        return "Informe del Arquero:\n"
                + "Nombre: " + getNombre() + "\n"
                + "Pais: " + getPais() + "\n"
                + "Nivel de experiencia: " + getNivelExperiencia() + "\n"
                + "Numero de camiseta: " + getNroCamiseta() + "\n"
                + "Partidos disputados: " + getPartidosDisputados() + "\n"
                + "Atajadas realizadas: " + getAtajadasRealizadas();
    } 
}
