
package primerrecuperatorioprograii;

public interface Entrenable {
    
    String entrenar();
    
}
