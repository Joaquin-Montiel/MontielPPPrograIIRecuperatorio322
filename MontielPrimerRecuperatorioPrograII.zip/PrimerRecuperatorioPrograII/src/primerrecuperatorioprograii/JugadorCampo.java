
package primerrecuperatorioprograii;


public class JugadorCampo extends Futbolista{
    
    private int golesConvertidos;

    public JugadorCampo(String nombre, String pais, NivelDeExperiencia nivelExperiencia, int nroCamiseta, int partidosDisputados, int golesConvertidos) {
        super(nombre, pais, nivelExperiencia, nroCamiseta, partidosDisputados);
        validarNoNegativo(golesConvertidos, "golesConvertidos");
        this.golesConvertidos = golesConvertidos;
    }

    public int getGolesConvertidos() {
        return this.golesConvertidos;
    }

    @Override
    public String toString() {
        return super.toString() + " JugadorCampo{" + "golesConvertidos=" + golesConvertidos + '}';
    }
}
