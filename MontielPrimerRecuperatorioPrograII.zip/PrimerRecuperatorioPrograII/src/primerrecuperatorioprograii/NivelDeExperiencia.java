
package primerrecuperatorioprograii;

public enum NivelDeExperiencia {
    DEBUTANTE,
    EXPERIMENTADO,
    VETERANO
}
