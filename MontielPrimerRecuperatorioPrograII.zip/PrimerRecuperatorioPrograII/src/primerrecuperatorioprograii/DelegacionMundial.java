
package primerrecuperatorioprograii;

import java.util.ArrayList;
import java.util.List;

public class DelegacionMundial {
    private String nombre;
    private List<Participante> participantes;
    
    public DelegacionMundial(String nombre) {
        validarString(nombre, "nombre");
        this.nombre = nombre;
        this.participantes = new ArrayList<>();
    }
    
    /**
     * Valida que una cadena de texto  o sea nula ni vacía.
     * @param valor: texto a validar.
     * @param campo: nombre del campo validado.
     * 
     * @throws IllegalArgumentException si el texto es inválido.
    */
    protected void validarString(String valor, String campo){
        if (valor == null || valor.isBlank()){
            throw new IllegalArgumentException("El " + campo + " no puede estar vacío.");
        }
    }

    public String getNombre() {
        return nombre;
    }
    
    public List<Participante> getParticipantes() {
        return new ArrayList<>(participantes);
    }

    @Override
    public String toString() {
        return "DelegacionMundial{" + "nombre=" + nombre + ", participantes=" + participantes + '}';
    }
    
    public void agregarParticipante(Participante participante)throws ParticipanteDuplicadoException {
        if (participante == null) {
            throw new IllegalArgumentException("No se puede agregar un participante nulo.");
        }

        if (participantes.contains(participante)) {
            throw new ParticipanteDuplicadoException("El participante ya se encuentra registrado.");
        }

        participantes.add(participante);
    }
    
    public List<Participante> obtenerParticipantes() {
        return new ArrayList<>(participantes);
    }
    
    public List<Participante> filtrarPorExperiencia(NivelDeExperiencia nivelExperiencia) {
        if (nivelExperiencia == null) {
            throw new IllegalArgumentException("El nivel de experiencia no puede ser nulo.");
        }

        List<Participante> filtrados = new ArrayList<>();

        for (Participante participante : participantes) {

            if (participante.getNivelExperiencia() == nivelExperiencia) {
                filtrados.add(participante);
            }
        }
        return filtrados;
    }
}
