
package primerrecuperatorioprograii;

import java.util.Objects;

public abstract class Participante {
    
    private String nombre;
    private String pais;
    private NivelDeExperiencia nivelExperiencia;

    public Participante(String nombre, String pais, NivelDeExperiencia nivelExperiencia) {
        validarEnum(nivelExperiencia);
        validarString(nombre, "nombre");
        validarString(pais, "pais");
        this.nombre = nombre;
        this.pais = pais;
        this.nivelExperiencia = nivelExperiencia;
    }
    
    /**
     * Valida que una cadena de texto  o sea nula ni vacía.
     * @param valor: texto a validar.
     * @param campo: nombre del campo validado.
     * 
     * @throws IllegalArgumentException si el texto es inválido.
     */
    protected void validarString(String valor, String campo){
        if (valor == null || valor.isBlank()){
            throw new IllegalArgumentException("El " + campo + " no puede estar vacío.");
        }
    }
    
    /**
     * Valida que el nivel de experiencia no sea nulo.
     * @param nivelExperiencia nivel de experiencia a validar.
     *
     * @throws IllegalArgumentException si el nivel de experiencia es nulo.
     */
    protected void validarEnum(NivelDeExperiencia nivelExperiencia){
        if (nivelExperiencia == null){
            throw new IllegalArgumentException("El nivel de experiencia no puede ser nulo.");
        }
    }
    
    protected void validarNoNegativo(int valor, String campo){
        if(valor < 0){
            throw new IllegalArgumentException("El " + campo + " no puede ser negativo.");
        }
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getPais() {
        return this.pais;
    }

    public NivelDeExperiencia getNivelExperiencia() {
        return this.nivelExperiencia;
    }

    @Override
    public String toString() {
        return "Participante{" + "nombre=" + nombre + ", pais=" + pais + ", nivelExperiencia=" + nivelExperiencia + '}';
    }
    
    @Override
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }   

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Participante otro = (Participante) obj;

        return nombre.equals(otro.getNombre())&& pais.equals(otro.getPais());
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre, pais);
    }
}
