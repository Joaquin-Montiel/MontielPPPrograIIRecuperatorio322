
package primerrecuperatorioprograii;

public class Arbitro extends Participante implements Informable {
    
    private int partidosDirigidos;

    public Arbitro(String nombre, String pais, NivelDeExperiencia nivelExperiencia, int partidosDirigidos) {
        super(nombre, pais, nivelExperiencia);
        validarNoNegativo(partidosDirigidos, "partidosDirigidos");
        this.partidosDirigidos = partidosDirigidos;
    }

    public int getPartidosDirigidos() {
        return this.partidosDirigidos;
    }

    @Override
    public String toString() {
        return super.toString() + " Arbitro{" + "partidosDirigidos=" + partidosDirigidos + '}';
    }
    
    @Override
    public String generarInforme() {
        return "Informe del Arbitro:\n"
                + "Nombre: " + getNombre() + "\n"
                + "Pais: " + getPais() + "\n"
                + "Nivel de experiencia: " + getNivelExperiencia() + "\n"
                + "Partidos Dirigidos: " + getPartidosDirigidos();
    } 
}
