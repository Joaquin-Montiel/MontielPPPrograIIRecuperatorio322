
package primerrecuperatorioprograii;

public abstract class Futbolista extends Participante implements Entrenable{
    
    private int nroCamiseta;
    private int partidosDisputados;

    public Futbolista(String nombre, String pais, NivelDeExperiencia nivelExperiencia, int nroCamiseta, int partidosDisputados) {
        super(nombre, pais, nivelExperiencia);
        validarNoNegativo(nroCamiseta, "nroCamiseta");
        validarNoNegativo(partidosDisputados, "partidosDisputado");
        this.nroCamiseta = nroCamiseta;
        this.partidosDisputados = partidosDisputados;
    }

    public int getNroCamiseta() {
        return this.nroCamiseta;
    }

    public int getPartidosDisputados() {
        return this.partidosDisputados;
    }

    @Override
    public String toString() {
        return "Futbolista{" + "nroCamiseta=" + nroCamiseta + ", partidosDisputados=" + partidosDisputados + '}';
    }

    @Override
    public String entrenar() {
        return "El futbolista " + getNombre() + " está entrenando.";
    }

}
