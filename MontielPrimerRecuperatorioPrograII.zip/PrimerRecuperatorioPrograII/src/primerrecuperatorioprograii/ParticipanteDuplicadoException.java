
package primerrecuperatorioprograii;

public class ParticipanteDuplicadoException extends Exception {
    
    public ParticipanteDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
